package it.unica.pr2.risorseWeb;

public class PaginaWeb extends RisorsaWeb {
    
    public PaginaWeb(String nome, String contenuto) {
        super(nome, contenuto);
    }
}